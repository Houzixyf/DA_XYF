package de.tud.et.ifa;

public class HelloWorld {
	
	/** 
	 *	Das ist die Main-Methode in Java; sie gilt als 
	 *	Einsprungpunkt für die Virtual Machine
	 *  
	 *	@param args Liste der Parameter, die beim Start des 
	 *				Programms übergeben wurden
	 *	@author Stefan Hennig, 2010
	 */
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}